const express = require('express');
const router = express.Router();
const reportesController = require('../controllers/reportesController');
const auth = require('../middlewares/authMiddleware');

// 1. Reporte de estudiantes graduados en un rango de fechas
router.get('/graduados', auth, reportesController.getGraduados);

// 2. Reporte de trabajos pendientes por estado
router.get('/trabajos-pendientes', auth, reportesController.getTrabajosPendientes);

// 3. Reporte de calificaciones promedio por modalidad
router.get('/calificaciones-promedio', auth, reportesController.getCalificacionesPromedio);

// 4. Reporte de carga de trabajo de docentes como tutores
router.get('/carga-tutores', auth, reportesController.getCargaTutores);

// 6. Reporte de tendencias de rendimiento académico
router.get('/tendencias-rendimiento', auth, reportesController.getTendenciasRendimiento);

// 7. Resumen para el dashboard del decanato
router.get('/dashboard-summary', auth, reportesController.getDashboardSummary);

// 8. Reporte de estudiantes graduados en un rango de fechas
router.get('/graduados/excel', auth, reportesController.generarReporteGraduados);
router.get('/carga-tutores/excel', auth, reportesController.generarReporteCargaTutores);
router.get('/trabajos-pendientes/excel', auth, reportesController.generarReporteTrabajosPendientes);
router.get('/calificaciones-promedio/excel', auth, reportesController.generarReporteCalificacionesPromedio);
router.get('/tendencias-rendimiento/excel', auth, reportesController.generarReporteTendenciasRendimiento);

module.exports = router;